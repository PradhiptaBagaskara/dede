<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_kategori2 extends MY_Model {

	public function __construct(){
    $table = "kategori";
    parent::__construct($table);
  }

 }

/* End of file M_kategori.php */
/* Location: ./application/models/M_kategori.php */
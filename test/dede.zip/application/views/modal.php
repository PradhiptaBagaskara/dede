<div id="myModal" class="modal bd-example-modal-lg animated bounceInDown" role="dialog" aria-labelledby="modalTitle">
                   <div class="modal-dialog modal-dialog-centered modal-lg">
                  <!-- konten modal-->
                  <div class="modal-content">
                    <!-- heading modal -->
                    <div class="modal-header card-header bg-primary">

                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <!-- body modal -->
                    <div class="modal-body">
                      <?= $value['isi'] ?>

                    </div>
                    <!-- footer modal -->
                    
                  </div>
                   </div>
                </div>